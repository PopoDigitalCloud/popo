apt install git
apt install bash
apt install curl
apt install lolcat
git clone https://github.com/tukangiseng/TebasIndex
cd Tebas
sh Tebas.sh
